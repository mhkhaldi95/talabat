<?php

namespace App\Http\Resources\UserManagement\Customers;

use App\Constants\Enum;
use Illuminate\Http\Resources\Json\JsonResource;

class CustomerResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'email' => $this->email,
            'phone' => $this->phone,
            'gender' => $this->getGender($this->gender)
        ];
    }
    public function getGender($gender){
        if($gender == Enum::MALE){
            return __('lang.male');
        }elseif ($gender == Enum::FEMALE){
            return __('lang.female');
        }else{
            return "-";
        }
    }
}
