
<div class="form-check form-check-sm form-check-custom form-check-solid">
    <input class="form-check-input" type="checkbox" value="<?php echo e($item->id); ?>" />
</div>
<?php /**PATH D:\www\talabat\resources\views/dashboard/products/partial/datatable_cols/_id.blade.php ENDPATH**/ ?>