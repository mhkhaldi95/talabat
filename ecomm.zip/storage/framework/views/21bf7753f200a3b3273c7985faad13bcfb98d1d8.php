<?php $__env->startSection('content'); ?>

    <!--begin::Post-->
    <div class="post d-flex flex-column-fluid" id="kt_post">
        <!--begin::Container-->
        <div id="kt_content_container" class="container-xxl">
            <!--begin::Card-->
            <div class="card">
                <?php echo $__env->make('validation.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!--begin::Form-->
                <form id="kt_docs_formvalidation_text" class="form p-4" method="post" action="<?php echo e(isset($item)?route('admins.update',$item->id):route('admins.store')); ?>" autocomplete="off" >
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <!--begin::Input group-->
                        <div class="col-6 mb-10">
                            <!--begin::Label-->
                            <label class=" fw-semibold fs-6 mb-2"><?php echo e(__('lang.name')); ?></label>
                            <!--end::Label-->

                            <!--begin::Input-->
                            <input type="text" name="name" class="form-control form-control-solid mb-3 mb-lg-0" placeholder="<?php echo e(__('lang.name')); ?>" value="<?php echo e(isset($item)?$item->name:''); ?>" />
                            <!--end::Input-->
                        </div>
                        <!--end::Input group-->
                        <!--begin::Input group-->
                        <div class="col-6 mb-10">
                            <!--begin::Label-->
                            <label class=" fw-semibold fs-6 mb-2"><?php echo e(__('lang.email')); ?></label>
                            <!--end::Label-->

                            <!--begin::Input-->
                            <input type="email" name="email" class="form-control form-control-solid mb-3 mb-lg-0" placeholder="<?php echo e(__('lang.email')); ?>" value="<?php echo e(isset($item)?$item->email:''); ?>" />
                            <!--end::Input-->
                        </div>
                        <!--end::Input group-->
                    </div>

                    <div class="row">
                        <!--begin::Input group-->
                        <div class="col-6 mb-10">
                            <!--begin::Label-->
                            <label class=" fw-semibold fs-6 mb-2"><?php echo e(__('lang.password')); ?></label>
                            <!--end::Label-->

                            <!--begin::Input-->
                            <input type="password" name="password" class="form-control form-control-solid mb-3 mb-lg-0" placeholder="<?php echo e(__('lang.password')); ?>" value="" />
                            <!--end::Input-->
                        </div>
                        <!--end::Input group-->
                        <!--begin::Input group-->
                        <div class="col-6 mb-10">
                            <!--begin::Label-->
                            <label class="fw-semibold fs-6 mb-2"><?php echo e(__('lang.password_confirmation')); ?></label>
                            <!--end::Label-->

                            <!--begin::Input-->
                            <input type="password" name="password_confirmation" class="form-control form-control-solid mb-3 mb-lg-0" placeholder="<?php echo e(__('lang.password_confirmation')); ?>" value="" />
                            <!--end::Input-->
                        </div>
                        <!--end::Input group-->
                    </div>
                    <div class="row">
                        <!--begin::Input group-->
                        <div class="col-6 mb-10">
                            <!--begin::Label-->
                            <label class=" fw-semibold fs-6 mb-2"><?php echo e(__('lang.roles')); ?></label>
                            <!--end::Label-->

                            <!--begin::Input-->
                            <select class="form-control select2" id="kt_select2_3" name="roles[]" multiple="multiple">
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role->id); ?>"<?php echo e(isset($item)?in_array($role->id,$role_user)?'selected':'':''); ?> ><?php echo e($role->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <!--end::Input-->
                        </div>
                        <!--end::Input group-->
                    </div>


                    <!--begin::Actions-->
                    <button id="kt_docs_formvalidation_text_submit1" type="submit" class="btn btn-primary">
                        <span class="indicator-label">
                           <?php echo e(__('lang.submit')); ?>

                        </span>
                                        <span class="indicator-progress">
                            Please wait... <span class="spinner-border spinner-border-sm align-middle ms-2"></span>
                        </span>
                    </button>
                    <!--end::Actions-->
                </form>
                <!--end::Form-->
            </div>
            <!--end::Card-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::Post-->
<?php $__env->stopSection(); ?>


















































































<?php $__env->startSection('scripts'); ?>
    <script>
        // Class definition
        var KTSelect2 = function() {
            // Private functions
            var demos = function() {

                // multi select
                $('#kt_select2_3').select2({
                    placeholder: "Select a state",
                });
            }


            // Public functions
            return {
                init: function() {
                    demos();
                }
            };
        }();

        // Initialization
        jQuery(document).ready(function() {
            KTSelect2.init();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\talabat\resources\views/dashboard/user_management/admins/create.blade.php ENDPATH**/ ?>