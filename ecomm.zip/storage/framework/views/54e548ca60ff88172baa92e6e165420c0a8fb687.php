<ul class="breadcrumb breadcrumb-separatorless fw-bold fs-7 my-1">
    <?php $__currentLoopData = $page_breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($bread['active']): ?>
            <!--begin::Item-->
            <li class="breadcrumb-item text-muted">
                <a href="<?php echo e($bread['page']); ?>" class="text-muted text-hover-primary"><?php echo e($bread['title']); ?></a>
            </li>
            <!--end::Item-->
            <!--begin::Item-->
            <li class="breadcrumb-item">
                <span class="bullet bg-gray-200 w-5px h-2px"></span>
            </li>
            <!--end::Item-->
        <?php else: ?>
            <!--begin::Item-->
            <li class="breadcrumb-item text-active"><?php echo e($bread['title']); ?></li>
            <!--end::Item-->
        <?php endif; ?>



    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH D:\www\talabat\resources\views/layout/breadcrumb.blade.php ENDPATH**/ ?>