<?php $__env->startSection('content'); ?>

    <!--begin::Post-->
    <div class="post d-flex flex-column-fluid" id="kt_post">
        <!--begin::Container-->
        <div id="kt_content_container" class="container-xxl">
            <!--begin::Card-->
            <div class="card">
                <?php echo $__env->make('validation.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!--begin::Form-->
                <form id="kt_docs_formvalidation_text" class="form p-4" method="post" action="<?php echo e(isset($item)?route('categories.store',$item->id):route('categories.store')); ?>" autocomplete="off" >
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <!--begin::Input group-->
                        <div class="col mb-10">
                            <!--begin::Label-->
                            <label class=" fw-semibold fs-6 mb-2"><?php echo e(__('lang.name_ar')); ?></label>
                            <!--end::Label-->

                            <!--begin::Input-->
                            <input type="text" name="name_ar" class="form-control form-control-solid mb-3 mb-lg-0" placeholder="<?php echo e(__('lang.name_ar')); ?>" value="<?php echo e(isset($item)?$item->name:''); ?>" />
                            <!--end::Input-->
                        </div>
                        <!--end::Input group-->
                        <!--begin::Input group-->
                        <div class="col mb-10">
                            <!--begin::Label-->
                            <label class=" fw-semibold fs-6 mb-2"><?php echo e(__('lang.name_en')); ?></label>
                            <!--end::Label-->

                            <!--begin::Input-->
                            <input type="text" name="name_en" class="form-control form-control-solid mb-3 mb-lg-0" placeholder="<?php echo e(__('lang.name_en')); ?>" value="<?php echo e(isset($item)?$item->name:''); ?>" />
                            <!--end::Input-->
                        </div>
                        <!--end::Input group-->
                    </div>


                    <!--begin::Actions-->
                    <button id="kt_docs_formvalidation_text_submit1" type="submit" class="btn btn-primary">
                        <span class="indicator-label">
                           <?php echo e(__('lang.submit')); ?>

                        </span>
                                        <span class="indicator-progress">
                            Please wait... <span class="spinner-border spinner-border-sm align-middle ms-2"></span>
                        </span>
                    </button>
                    <!--end::Actions-->
                </form>
                <!--end::Form-->
            </div>
            <!--end::Card-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::Post-->
<?php $__env->stopSection(); ?>


















































































<?php $__env->startSection('scripts'); ?>
    <script>
        // Class definition
        var KTSelect2 = function() {
            // Private functions
            var demos = function() {

                // multi select
                $('#kt_select2_3').select2({
                    placeholder: "Select a state",
                });
            }


            // Public functions
            return {
                init: function() {
                    demos();
                }
            };
        }();

        // Initialization
        jQuery(document).ready(function() {
            KTSelect2.init();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\talabat\resources\views/dashboard/categories/create.blade.php ENDPATH**/ ?>