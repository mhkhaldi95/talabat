<div class="badge badge-light-<?php echo e($item->status == \App\Constants\Enum::PUBLISHED ?'success':($item->status == \App\Constants\Enum::INACTIVE?'danger':'')); ?>">
<?php echo e($item->status == \App\Constants\Enum::PUBLISHED ? __('lang.Published'):($item->status == \App\Constants\Enum::INACTIVE?__('lang.Inactive'):'--')); ?>

</div>
<?php /**PATH D:\www\talabat\resources\views/dashboard/products/partial/datatable_cols/_status.blade.php ENDPATH**/ ?>