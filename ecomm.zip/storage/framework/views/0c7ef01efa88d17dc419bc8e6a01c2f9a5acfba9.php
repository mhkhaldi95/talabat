<span class="fw-bolder text-dark"><?php echo e($item->price); ?></span>
<?php /**PATH D:\www\talabat\resources\views/dashboard/products/partial/datatable_cols/_price.blade.php ENDPATH**/ ?>