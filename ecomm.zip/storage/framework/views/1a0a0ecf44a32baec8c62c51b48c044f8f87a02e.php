<?php $__env->startSection('content'); ?>

    <!--begin::Post-->
    <div class="post d-flex flex-column-fluid" id="kt_post">
        <!--begin::Container-->
        <div id="kt_content_container" class="container-xxl">
            <!--begin::Card-->
            <div class="card">
                <?php echo $__env->make('validation.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!--begin::Form-->
                <form id="kt_docs_formvalidation_text" class="form p-4" method="post" action="<?php echo e(isset($item)?route('customers.store',$item->id):route('customers.store')); ?>" autocomplete="off" >
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <!--begin::Input group-->
                        <div class="col-6 mb-10">
                            <!--begin::Label-->
                            <label class=" fw-semibold fs-6 mb-2"><?php echo e(__('lang.name')); ?></label>
                            <!--end::Label-->

                            <!--begin::Input-->
                            <input type="text" name="name" class="form-control form-control-solid mb-3 mb-lg-0" placeholder="<?php echo e(__('lang.name')); ?>" value="<?php echo e(isset($item)?$item->name:''); ?>" />
                            <!--end::Input-->
                        </div>
                        <!--end::Input group-->
                        <!--begin::Input group-->
                        <div class="col-6 mb-10">
                            <!--begin::Label-->
                            <label class=" fw-semibold fs-6 mb-2"><?php echo e(__('lang.email')); ?></label>
                            <!--end::Label-->

                            <!--begin::Input-->
                            <input type="email" name="email" class="form-control form-control-solid mb-3 mb-lg-0" placeholder="<?php echo e(__('lang.email')); ?>" value="<?php echo e(isset($item)?$item->email:''); ?>" />
                            <!--end::Input-->
                        </div>
                        <!--end::Input group-->
                    </div>
                    <div class="row">
                        <!--begin::Input group-->
                        <div class="col-6 mb-10">
                            <!--begin::Label-->
                            <label class=" fw-semibold fs-6 mb-2"><?php echo e(__('lang.phone')); ?></label>
                            <!--end::Label-->

                            <!--begin::Input-->
                            <input type="text" name="phone" class="form-control form-control-solid mb-3 mb-lg-0" placeholder="<?php echo e(__('lang.phone')); ?>" value="<?php echo e(isset($item)?$item->phone:''); ?>" />
                            <!--end::Input-->
                        </div>
                        <!--end::Input group-->
                        <!--begin::Input group-->
                        <div class="col-6 mb-10">
                            <!--begin::Label-->
                            <label class=" fw-semibold fs-6 mb-2"><?php echo e(__('lang.gender')); ?></label>
                            <!--end::Label-->
                            <!--begin::Input-->
                            <select class="form-select form-select-solid" data-control="select2" data-placeholder="Select an option" name="gender">
                                    <option value="<?php echo e(\App\Constants\Enum::MALE); ?>" <?php echo e(isset($item)?$item->gender == \App\Constants\Enum::MALE ?'selected':'':''); ?> ><?php echo e(__('lang.male')); ?></option>
                                    <option value="<?php echo e(\App\Constants\Enum::FEMALE); ?>" <?php echo e(isset($item)?$item->gender == \App\Constants\Enum::FEMALE ?'selected':'':''); ?> ><?php echo e(__('lang.female')); ?></option>
                            </select>
                            <!--end::Input-->
                        </div>
                        <!--end::Input group-->
                    </div>


                    <!--begin::Actions-->
                    <button id="kt_docs_formvalidation_text_submit1" type="submit" class="btn btn-primary">
                        <span class="indicator-label">
                           <?php echo e(__('lang.submit')); ?>

                        </span>
                                        <span class="indicator-progress">
                            Please wait... <span class="spinner-border spinner-border-sm align-middle ms-2"></span>
                        </span>
                    </button>
                    <!--end::Actions-->
                </form>
                <!--end::Form-->
            </div>
            <!--end::Card-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::Post-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\talabat\resources\views/dashboard/user_management/customers/create.blade.php ENDPATH**/ ?>