<div class="d-flex align-items-center">
    <!--begin::Thumbnail-->
    <a href="#" class="symbol symbol-50px">
        <span class="symbol-label" style="background-image:url(<?php echo e($item->avatar); ?>);"></span>
    </a>
    <!--end::Thumbnail-->
    <div class="ms-5">
        <!--begin::Title-->
        <a href="#" class="text-gray-800 text-hover-primary fs-5 fw-bolder" data-kt-ecommerce-product-filter="product_name"><?php echo e($item->name); ?></a>
        <!--end::Title-->
    </div>
</div>
<?php /**PATH D:\www\talabat\resources\views/dashboard/products/partial/_name.blade.php ENDPATH**/ ?>