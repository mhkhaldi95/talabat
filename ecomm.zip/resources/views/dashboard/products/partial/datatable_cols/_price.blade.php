<span class="fw-bolder text-dark">{{$item->price   }}</span>
